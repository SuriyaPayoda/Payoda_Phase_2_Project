﻿namespace IConnect_Version04.Models
{
    public class ViewStatus
    {
        public int UId { get; set; }
        public string CName { get; set; }
        public string JRole { get; set; }
        public string USkill { get; set; }
        public int UExperience { get; set; }
        public string JStatus { get; set; }
    }
}
