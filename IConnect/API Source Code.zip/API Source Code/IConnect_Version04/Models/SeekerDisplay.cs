﻿namespace IConnect_Version04.Models
{
    public class SeekerDisplay
    {
        public int UId { get; set; }

        public string UFirstname { get; set; }

        public string ULastname { get; set; }

        public string UEmail { get; set; }

        public long UPhno { get; set; }

        public string UCourse { get; set; }

        public string USpecification { get; set; }

        public string UCoursetype { get; set; }

        public string UCollege { get; set; }

        public string UGender { get; set; }

        public DateTime UDob { get; set; }
        public string USkill { get; set; } 

        public int UExperience { get; set; }

        public DateTime UAppliedon { get; set; }
        
        public string JRole { get; set; }



    }
}
