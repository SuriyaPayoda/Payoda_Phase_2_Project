﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace IConnect_Version04.Models;

public partial class CompanyRegisteration
{
    public int CId { get; set; }

    public string CName { get; set; } = null!;

    public string CEmail { get; set; } = null!;

    public string CPassword { get; set; } = null!;

    public long CPhno { get; set; }

    public string? CImage { get; set; }

    public int? Ispermit { get; set; }

    public int? Isactive { get; set; }
    [JsonIgnore]
    public virtual ICollection<JobDetail> JobDetails { get; set; } = new List<JobDetail>();
}
