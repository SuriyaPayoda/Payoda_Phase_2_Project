﻿using IConnect_Version04.Models;

namespace IConnect_Version04.Repository.IService
{
    public interface IHomeService
    {
        public Task<List<UserRegisteration>> UserRegister(UserRegisteration user);
        public Task<Login> SeekerLogin(Login user);
        public Task<List<CompanyRegisteration>> CompanyRegister(CompanyRegisteration user);
        public Task<Login> CompanyLogin(Login user);
    }
}
