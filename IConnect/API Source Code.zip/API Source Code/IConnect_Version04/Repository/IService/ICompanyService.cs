﻿using IConnect_Version04.Models;

namespace IConnect_Version04.Repository.IService
{
    public interface ICompanyService
    {
        public Task<CompanyRegisteration> UploadPhoto(IFormFile file, int Cid);
        public Task<List<JobDetail>> JobPost(GetJobDetails jobpost);
        public Task<JobDetail> UpdateJob(int Jid, JobDetail user);
        public Task<JobDetail> DeleteJob(int Jid);
        public Task<Boolean> GetResume(string resumeurl);
        public Task<List<SeekerDisplay>> GetUserJobInfo(int cid);
        public Task<List<JobView>> GetJobDetails(int cid);
    }
}
