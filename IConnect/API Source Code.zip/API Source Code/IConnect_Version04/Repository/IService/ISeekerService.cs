﻿using IConnect_Version04.Models;
using System.Threading.Tasks;

namespace IConnect_Version04.Repository.IService
{
    public interface ISeekerService
    {
        public Task<UserRegisteration> Updateprofile(int Uid, UserRegisteration user);
        public Task<UserRegisteration> UploadPhoto(IFormFile file, int Uid);
        public Task<UserRegisteration> UploadResume(IFormFile file, int Uid);
        public Task<List<JobApply>> JobApply(JobApply job);
        public Task<List<CompanyDisplay>> GetCompanyInfo();
        public Task<List<ViewStatus>> ViewStatus(int uid);
    }
}
