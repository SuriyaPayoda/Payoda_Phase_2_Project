﻿using IConnect_Version04.Repository.IService;
using IConnect_Version04.Models;
using Microsoft.EntityFrameworkCore;
using System.Net;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection.Metadata;
using System;

namespace IConnect_Version04.Repository.Service
{
    public class CompanyService : ICompanyService
    {
        public IconnectDbContext _iconnectContext;

        public CompanyService(IconnectDbContext iconnectDbContext)
        {
            _iconnectContext = iconnectDbContext;
        }
        public async Task<CompanyRegisteration> UploadPhoto(IFormFile file, int Cid)
        {
            if (file == null || file.Length == 0)
            {
                return null;
            }
            else
            {
                var fileName = $"{DateTime.Now:yyyyMMddHHmmss}_{Cid}";
                var filePath = Path.Combine("Data/Company", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
                var ruser = await _iconnectContext.CompanyRegisterations.FindAsync(Cid);
                if (ruser != null)
                {
                    ruser.CImage = fileName;
                    _iconnectContext.SaveChanges();
                    ruser = await _iconnectContext.CompanyRegisterations.FindAsync(Cid);

                }

                return ruser;

            }
        }
        public async Task<List<JobDetail>> JobPost(GetJobDetails jobpost) {

            var jobType = await _iconnectContext.JobTypes.FirstOrDefaultAsync(jt => jt.TName == jobpost.TName);

            JobDetail job = new JobDetail();
            if (jobpost != null)
            {
                job.CId = jobpost.CId;
                job.JId = jobpost.JId;
                job.JSkill = jobpost.JSkill;
                job.JSalary = jobpost.JSalary;
                job.JVacancy = jobpost.JVacancy;
                job.JContact = jobpost.JContact;
                job.JUpdatedon = DateTime.Now;
                job.JHighlight = jobpost.JHighlight;
                job.JMaxexperience = jobpost.JMaxexperience;
                job.JMinexperience = jobpost.JMinexperience;
                job.JRole = jobpost.JRole;
                job.JLocation = jobpost.JLocation;
                job.Isactive = jobpost.Isactive;
                job.JTimeline = jobpost.JTimeline;
                job.TId = jobType.TId;
                _iconnectContext.JobDetails.Add(job);
                await _iconnectContext.SaveChangesAsync();
                return await _iconnectContext.JobDetails.ToListAsync();
            }
            else
            {
                throw new Exception("Not found");
            }
        }
        public async Task<JobDetail> UpdateJob(int Jid, JobDetail user)
        {
            var ruser = await _iconnectContext.JobDetails.FindAsync(Jid);
            if (ruser != null)
            {
                ruser.JRole = user.JRole;
                ruser.JTimeline = user.JTimeline;
                ruser.JMinexperience = user.JMinexperience;
                ruser.JMaxexperience = user.JMaxexperience;
                ruser.JVacancy = user.JVacancy;
                ruser.JSalary = user.JSalary;
                ruser.JSkill = user.JSkill;
                ruser.JContact = user.JContact;
                ruser.JHighlight = user.JHighlight;
                ruser.JLocation = user.JLocation;
                ruser.JUpdatedon = DateTime.Now;
                _iconnectContext.SaveChanges();
                ruser = await _iconnectContext.JobDetails.FindAsync(Jid);
                return ruser;

            }
            else
            {
                throw new Exception("Not found");
            }

        }
        public async Task<JobDetail> DeleteJob(int Jid)
        {
            var ruser = await _iconnectContext.JobDetails.FindAsync(Jid);
            if (ruser != null)
            {
                ruser.Isactive = 1;

                _iconnectContext.SaveChanges();
                ruser = await _iconnectContext.JobDetails.FindAsync(Jid);
                return ruser;

            }
            else
            {
                throw new Exception("Not found");
            }

        }

        public Task<Boolean> GetResume(string resumeurl)
        {
            string filePath = @"~\Data\Company\Resume\" +resumeurl;

            if (File.Exists(filePath))
            {
                HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK);

                // Read the file content
                byte[] fileBytes = File.ReadAllBytes(filePath);

                // Set response content
                response.Content = new ByteArrayContent(fileBytes);

                // Set the content type and file name
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                response.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                {
                    FileName = Path.GetFileName(filePath)
                };

            }
            return Task.FromResult(true);
            
        }

        public async Task<List<SeekerDisplay>> GetUserJobInfo(int cid)
        {
            var userData = await _iconnectContext.UserRegisterations.Where(user => user.Isactive == 0)
            .Join(
                _iconnectContext.JobApplies.Where(ja => ja.JStatus == "Pending"),
                user => user.UId,
                jobApply => jobApply.UId,
                (user, jobApply) => new SeekerDisplay
                {
                    UId = user.UId,
                    UFirstname = user.UFirstname,
                    ULastname = user.ULastname,
                    UPhno = user.UPhno,
                    UEmail = user.UEmail,
                    UCourse = user.UCourse,
                    UCoursetype = user.UCoursetype,
                    USpecification = user.USpecification,
                    UCollege = user.UCollege,
                    UGender = user.UGender,
                    UDob = (DateTime)user.UDob,


                    JRole = _iconnectContext.JobDetails
                        .Where(jd => jd.CId == cid)
                        .Select(jd => jd.JRole)
                        .FirstOrDefault(),
                    USkill = jobApply.USkill,
                    UExperience = jobApply.UExperience,
                    UAppliedon = jobApply.UAppliedon,

                }
            )

            .ToListAsync();

            return userData;

        }


            public async Task<List<JobView>> GetJobDetails(int cid)
            {
                var jobDetailsWithTypeName = await _iconnectContext.JobDetails
                    .Where(jobDetails => jobDetails.CId == cid)
                    .Join(
                        _iconnectContext.JobTypes,
                        jobDetails => jobDetails.TId,
                        jobType => jobType.TId,
                        (jobDetails, jobType) => new JobView
                        {
                            JId = jobDetails.JId,
                            CId = jobDetails.CId,
                            JRole = jobDetails.JRole,
                            JSkill = jobDetails.JSkill,
                            JMinexperience = jobDetails.JMinexperience,
                            JMaxexperience = jobDetails.JMaxexperience,
                            JVacancy = jobDetails.JVacancy,
                            JSalary = jobDetails.JSalary,
                            JHighlight = jobDetails.JHighlight,
                            JContact = jobDetails.JContact,
                            JTimeline = jobDetails.JTimeline,
                            JUpdatedon = jobDetails.JUpdatedon,
                            JLocation = jobDetails.JLocation,
                            Isactive = jobDetails.Isactive,
                            TName = jobType.TName
                        }
                    )
                    .ToListAsync();

                return jobDetailsWithTypeName;
            }
          
    }
}
