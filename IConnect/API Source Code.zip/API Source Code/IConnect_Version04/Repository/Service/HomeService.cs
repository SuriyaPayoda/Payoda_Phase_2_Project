﻿using IConnect_Version04.Models;
using IConnect_Version04.Repository.IService;
using Microsoft.EntityFrameworkCore;

namespace IConnect_Version04.Repository.Service
{

    public class HomeService:IHomeService
    {
        public IconnectDbContext _iconnectContext;

        public HomeService(IconnectDbContext iconnectContext)
        {
            _iconnectContext = iconnectContext;
        }

        public async Task<List<UserRegisteration>> UserRegister(UserRegisteration user)
        {
            if (user != null)
            {
                _iconnectContext.UserRegisterations.Add(user);
                await _iconnectContext.SaveChangesAsync();
                var users = await _iconnectContext.UserRegisterations.ToListAsync();
                return users;
            }
            else
            {
                throw new Exception("Not found");
            }
        }
        public async Task<Login> SeekerLogin(Login user)
        {
            var l_user = await _iconnectContext.UserRegisterations.FirstOrDefaultAsync(u => u.UEmail == user.username && u.UPassword == user.password);
            if (l_user == null)
            {
                throw new Exception("Not found");
            }
            else
            {
                return user;
            }
        }
        public async Task<List<CompanyRegisteration>> CompanyRegister(CompanyRegisteration user)
        {
            if (user != null)
            {
                _iconnectContext.CompanyRegisterations.Add(user);
                await _iconnectContext.SaveChangesAsync();
                return await _iconnectContext.CompanyRegisterations.ToListAsync();
            }
            else
            {
                throw new Exception("Not found");
            }
        }
        public async Task<Login> CompanyLogin(Login user)
        {
            var l_user = await _iconnectContext.CompanyRegisterations.FirstOrDefaultAsync(u => u.CEmail == user.username && u.CPassword == user.password);
            if (l_user == null)
            {
                throw new Exception("Not found");
            }
            else
            {
                return user;
            }
        }
    }
}
