﻿using IConnect_Version04.Models;
using IConnect_Version04.Repository.IService;
using IConnect_Version04.Repository.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IConnect_Version04
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        public IHomeService _homeService;

        public HomeController(IHomeService homeService)
        {
            _homeService = homeService;
        }
        [HttpPost("SeekerRegister")]
        public async Task<ActionResult<List<UserRegisteration>>> UserRegister(UserRegisteration user)
        {
            try
            {
                var users = await _homeService.UserRegister(user);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }

        [HttpPost("SeekerLogin")]
        public async Task<ActionResult<Login>> SeekerLogin(Login user)
        {
            try
            {
                var l_user = await _homeService.SeekerLogin(user);
                return Ok(l_user);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost("CompanyRegister")]
        public async Task<ActionResult<List<CompanyRegisteration>>> UserRegister(CompanyRegisteration user)
        {
            try
            {
                var users = await _homeService.CompanyRegister(user);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("CompanyLogin")]
        public async Task<ActionResult<Login>> CompanyLogin(Login user)
        {
            try
            {
                var l_user = await _homeService.CompanyLogin(user);
                return Ok(l_user);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

    }
}
