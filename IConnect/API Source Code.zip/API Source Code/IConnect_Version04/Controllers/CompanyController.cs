﻿using IConnect_Version04.Models;
using IConnect_Version04.Repository.IService;
using IConnect_Version04.Repository.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;

namespace IConnect_Version04
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        public ICompanyService _companyService;

        public CompanyController(ICompanyService companyService)
        {
            _companyService = companyService;
        }

        [HttpPut("PhotoUpload")]
        public async Task<ActionResult<CompanyRegisteration>> UploadPhoto(IFormFile file, int Cid)
        {
            try
            {
                var users = await _companyService.UploadPhoto(file, Cid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpPost("JobPost")]
        public async Task<ActionResult<List<JobDetail>>> JobPost(GetJobDetails jobpost)
        {
            try
            {
                var users = await _companyService.JobPost(jobpost);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpPut("UpdateJob")]
        public async Task<ActionResult<JobDetail>> UpdateJob(int Jid, JobDetail user)
        {
            try
            {
                var users = await _companyService.UpdateJob(Jid,user);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpDelete("DeleteJob")]
        public async Task<ActionResult<JobDetail>> DeleteJob(int Jid)
        {
            try
            {
                var users = await _companyService.DeleteJob(Jid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }

        [HttpGet("GetResume")]
        public async Task<ActionResult<Boolean>> GetResume(string resumeurl)
        {
            try
            {
                var users = await _companyService.GetResume(resumeurl);
                return Ok(true);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpGet("GetSeekers")]
        public async Task<ActionResult<List<SeekerDisplay>>> GetUserJobInfo(int cid)
        {
            try
            {
                var users = await _companyService.GetUserJobInfo(cid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpGet("ViewJob")]
        public async Task<ActionResult<List<JobView>>> GetJobDetails(int cid)
        {
            try
            {
                var users = await _companyService.GetJobDetails(cid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }

    }
}
