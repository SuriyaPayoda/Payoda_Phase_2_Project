﻿using IConnect_Version04.Models;
using IConnect_Version04.Repository.IService;
using IConnect_Version04.Repository.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IConnect_Version04
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeekerController : ControllerBase
    {
        public ISeekerService _seekerService;

        public SeekerController(ISeekerService seekerService)
        {
            _seekerService = seekerService;
        }
        [HttpPut("SeekerProfile")]
        public async Task<ActionResult<UserRegisteration>> Updateprofile(int Uid, UserRegisteration user)
        {
            try
            {
                var users = await _seekerService.Updateprofile(Uid,user);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }

        [HttpPut("PhotoUpload")]
        public async Task<ActionResult<UserRegisteration>> UploadPhoto(IFormFile file, int Uid)
        {
            try
            {
                var users = await _seekerService.UploadPhoto(file,Uid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpPut("ResumeUpload")]
        public async Task<ActionResult<UserRegisteration>> UploadResume(IFormFile file, int Uid)
        {
            try
            {
                var users = await _seekerService.UploadResume(file, Uid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpPost("JobApply")]
        public async Task<ActionResult<List<JobApply>>> JobApply(JobApply job)
        {
            try
            {
                var users = await _seekerService.JobApply(job);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpGet ("CompanyDetails")]
        public async Task<ActionResult<List<CompanyDisplay>>> GetCompanyInfo()
        {
            try
            {
                var users = await _seekerService.GetCompanyInfo();
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
        [HttpGet("ViewStatus")]
        public async Task<ActionResult<List<ViewStatus>>> ViewStatus(int uid)
        {
            try
            {
                var users = await _seekerService.ViewStatus(uid);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException);
            }
        }
    }
}
